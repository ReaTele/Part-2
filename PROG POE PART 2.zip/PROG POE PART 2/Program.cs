﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

class Ingredient
{
    public string Name { get; set; }
    public float Quantity { get; set; }
    public string UnitOfMeasurement { get; set; }
    public int Calories { get; set; }
    public string FoodGroup { get; set; }

    public Ingredient(string name, float quantity, string unitOfMeasurement, int calories, string foodGroup)
    {
        Name = name;
        Quantity = quantity;
        UnitOfMeasurement = unitOfMeasurement;
        Calories = calories;
        FoodGroup = foodGroup;
    }

    public void Scale(float factor)
    {
        Quantity *= factor;
    }

    private float originalQuantity;

    public void SaveOriginalQuantity()
    {
        originalQuantity = Quantity;
    }

    public void Reset()
    {
        Quantity = originalQuantity;
    }
}

class Step
{
    public string Description { get; set; }

    public Step(string description)
    {
        Description = description;
    }
}

class Recipe
{
    public string Name { get; set; }

    private List<Ingredient> ingredients;

    private List<Step> steps;

    public Recipe(string name)
    {
        Name = name;
        ingredients = new List<Ingredient>();
        steps = new List<Step>();
    }

    public void AddIngredient(string name, float quantity, string unitOfMeasurement, int calories, string foodGroup)
    {
        Ingredient ingredient = new Ingredient(name, quantity, unitOfMeasurement, calories, foodGroup);
        ingredients.Add(ingredient);
    }

    public void AddStep(string description)
    {
        Step step = new Step(description);
        steps.Add(step);
    }

    public void DisplayIngredients()
    {
        Console.WriteLine("Ingredients: ");
        
        foreach(Ingredient ingredient in ingredients)
        {
            Console.WriteLine("{0} {1} {2} {3} calories, {4})", ingredient.Quantity, ingredient.UnitOfMeasurement, ingredient.Name, ingredient.Calories, ingredient.FoodGroup);

        }
    }

    public void DisplaySteps()
    {
        Console.WriteLine("Steps:");

        for(int i = 0; i < steps.Count; i++)
        {
            Console.WriteLine("{0}. {1}", i + 1, steps[i].Description);
        }
    }

    public void Scale(float factor)
    {
        foreach(Ingredient ingredient in ingredients)
        {
            ingredient.Scale(factor);
        }
    }

    public void ResetQuantities()
    {
        foreach(Ingredient ingredient in ingredients)
        {
            ingredient.Reset();
        }
    }

    public void Clear()
    {
        ingredients.Clear();
        steps.Clear();
    }

    public int CalculateTotalCalories()
    {
        int totalCalories = 0;

        foreach(Ingredient ingredient in ingredients)
        {
            totalCalories += ingredient.Calories;
        }
        return totalCalories;
    }
}


internal class Program
{
    static List<Recipe> recipes = new List<Recipe>();
    private static void Main(string[] args)
    {
        while (true)
        {
            Console.WriteLine("Enter 1 to create a recipe");
            Console.WriteLine("Enter 2 to diplay all recipes");
            Console.WriteLine("Enter 3 to display a recipe");
            Console.WriteLine("Enter 4 to scale a recipe");
            Console.WriteLine("Enter 5 to reset quantities");
            Console.WriteLine("Enter 6 to clear a recipe");
            Console.WriteLine("Enter 7 to exit the application");
            Console.WriteLine("Enter your choice");

            int choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    CreateRecipe();
                    break;

                case 2:
                    DisplayAllRecipes();
                    break;

                case 3:
                    DisplayAllRecipes();
                    break;

                case 4:
                    ScaleRecipe();
                    break;

                case 5:
                    ResetQuantities();
                    break;

                case 6:
                    ClearRecipe();
                    break;

                case 7:
                    ExitApplication();
                        break;
                default:

                    Console.WriteLine("Invalid choice!");
                    break;
               }

            }
        }

    static void CreateRecipe()
    {
        Console.Write("Enter the name of the recipe:");
        string name = Console.ReadLine();

        Recipe recipe = new Recipe(name);

        Console.WriteLine("Enter the number of ingredients:");
        int numingredients = Convert.ToInt32(Console.ReadLine());

        for(int x = 0; x < numingredients; x++)
        {
            Console.WriteLine($"Ingredient {x + 1}:");
            Console.WriteLine("Name:");
            string ingredientName = Console.ReadLine();

            Console.WriteLine("Quantity:");
            float quantity = Convert.ToSingle(Console.ReadLine());

            Console.WriteLine("Unit Of Measurement: ");
            string unitOfMeasurement = Console.ReadLine();

            Console.WriteLine("Calories: ");
            int calories = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Food Group:");
            string foodGroup = Console.ReadLine();

            recipe.AddIngredient(ingredientName, quantity, unitOfMeasurement, calories, foodGroup); 
        }

        Console.WriteLine("Enter the number of steps: ");
        int numSteps = Convert.ToInt32(Console.ReadLine());

        for(int r = 0; r < numSteps; r++)
        {
            Console.WriteLine($"Step {r + 1}: ");
            Console.WriteLine("Description: ");
            string description = Console.ReadLine();

            recipe.AddStep(description);
        }

        recipes.Add(recipe);

        Console.WriteLine("Recipe created successfully!");
        Console.WriteLine();
    }

    static void DisplayAllRecipes()
    {
        if(recipes.Count == 0)
        {
            Console.WriteLine("No recipe found.");
            Console.WriteLine();
            return;
        }

        recipes.Sort((r1, r2) => r1.Name.CompareTo(r2.Name));

        Console.WriteLine("List of Recipes:");

        foreach(Recipe recipe in recipes)
        {
            Console.WriteLine(recipe.Name);
        }

        Console.WriteLine();
    }

    static void DisplayRecipe()
    {
        if(recipes.Count == 0)
        {
            Console.WriteLine("No recipes found. ");
            Console.WriteLine();
            return;
        }

        Console.WriteLine("Enter the name of the recipe to display:");
        string recipeName = Console.ReadLine();

        Recipe recipe = recipes.FirstOrDefault(r => r.Name == recipeName);

        if(recipe != null)
        {
            Console.WriteLine("Recipe:");

            Console.WriteLine($"Name: {recipe.Name}");
            recipe.DisplayIngredients();
            recipe.DisplaySteps();

            Console.WriteLine($"Total Calories: {recipe.CalculateTotalCalories()}");

            if(recipe.CalculateTotalCalories() > 300)
            {
                Console.WriteLine("Warning: This recipe exceeds 300 calories!");
            }
        }
        else
        {
            Console.WriteLine("Recipe not found.");
        }

        Console.WriteLine();
    }

    static void ScaleRecipe()
    {
        if(recipes.Count == 0)
        {
            Console.WriteLine("No recipe found.");
            Console.WriteLine();
            return;
        }

        Console.WriteLine("Enter the name of the recipe to scale: ");
        string recipeName = Console.ReadLine();

        Recipe recipe = recipes.FirstOrDefault(r => r.Name == recipeName);

        if(recipe != null)
        {
            Console.WriteLine("Enter the scaling factor (0.5, 1, 2, 3): ");
            float factor = Convert.ToSingle(Console.ReadLine());

            if(factor == 0.5f || factor == 3f)
            {
                recipe.Scale(factor);
                Console.WriteLine("Recipe scaled successfully!");
            }
            else
            {
                Console.WriteLine("Invalid scaling factor. Recipe scaling failed.");
            }
        }
        else
        {
            Console.WriteLine("Recipe not found.");
        }

        Console.WriteLine();
    }

    static void ResetQuantities()
    {
        if(recipes.Count == 0)
        {
            Console.WriteLine("No recipes found.");
            Console.WriteLine();
            return;
        }

        Console.WriteLine("Enter the name of the recipe to reset quantities:");
        string recipeName = Console.ReadLine();

        Recipe recipe = recipes.FirstOrDefault(r => r.Name == recipeName);

        if(recipe != null)
        {
            recipe.ResetQuantities();
            Console.WriteLine("Quantities reset successfully!");
        }
        else
        {
            Console.WriteLine("Recipe not found");
        }

        Console.WriteLine();
     
    }

    static void ClearRecipe()
    {
        if (recipes.Count == 0)
        {
            Console.WriteLine("No recipes found.");
            Console.WriteLine();
            return;
        }

        Console.WriteLine("Enter the name of the recipe to claer: ");
        string recipeName = Console.ReadLine();

        Recipe recipe = recipes.FirstOrDefault(r => r.Name == recipeName);

        if (recipe != null)
        {
            recipes.Remove(recipe);
            Console.WriteLine("Recipe cleared successfully!");
        }
        else
        {
            Console.WriteLine("Recipe no found.");
        }

        Console.WriteLine();

    }

    static void ExitApplication()
    {
        Console.WriteLine("Exiting the application....");
        Environment.Exit(0);
    }

}